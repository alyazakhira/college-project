package com.example.tugasanimasi;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity {
    private ObjectAnimator ltAnimator, stAnimator, sAnimator, c1Animator, c2Animator, c3Animator;
    private GifImageView ltImage, stImage, sImage;
    private ImageView c1Image, c2Image, c3Image;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ltImage = findViewById(R.id.image_tree_big);
        stImage = findViewById(R.id.image_tree_small);
        sImage = findViewById(R.id.image_sakura);
        c1Image = findViewById(R.id.image_chat1);
        c2Image = findViewById(R.id.image_chat2);
        c3Image = findViewById(R.id.image_chat3);
        button = findViewById(R.id.btn_animate);

        stAnimator = ObjectAnimator.ofFloat(stImage, "x", 1000);
        ltAnimator = ObjectAnimator.ofFloat(ltImage, "x", 2000);
        sAnimator = ObjectAnimator.ofFloat(sImage, "x", 3000);
        c1Animator = ObjectAnimator.ofFloat(c1Image, "alpha", 1);
        c2Animator = ObjectAnimator.ofFloat(c2Image, "alpha", 1);
        c3Animator = ObjectAnimator.ofFloat(c3Image, "alpha", 1);
        
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stAnimator.setDuration(4000);
                stAnimator.start();

                ltAnimator.setDuration(15000);
                ltAnimator.start();

                sAnimator.setDuration(20000);
                sAnimator.start();

                c1Animator.setDuration(1000);
                c1Animator.start();

                c2Animator.setDuration(10000);
                c2Animator.start();

                c3Animator.setDuration(20000);
                c3Animator.start();
            }
        });
    }
}