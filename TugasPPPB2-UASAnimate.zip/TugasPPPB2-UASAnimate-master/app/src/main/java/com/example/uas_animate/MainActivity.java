package com.example.uas_animate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView mImgView;
    Bitmap mBitmap;
    Canvas mCanvas;
    private int mColorBackground;
    Paint mCirclePaint = new Paint();
    Paint mHeadPaint = new Paint();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mImgView = findViewById(R.id.my_img_view);

        mCirclePaint.setColor(getResources().getColor(R.color.black));
        mHeadPaint.setColor(getResources().getColor(R.color.white));

        mImgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator mAnimator = ObjectAnimator.ofFloat(mImgView, "alpha", 1);
                mAnimator.setDuration(2000);
                mAnimator.start();
                ObjectAnimator mAnimator2 = ObjectAnimator.ofFloat(mImgView, "rotationY", 180);
                mAnimator2.setStartDelay(2000);
                mAnimator2.setDuration(2000);
                mAnimator2.start();
                ObjectAnimator mAnimator3 = ObjectAnimator.ofFloat(mImgView, "alpha", 0);
                mAnimator3.setStartDelay(4000);
                mAnimator3.setDuration(2000);
                mAnimator3.start();
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        int vWidth = mImgView.getWidth();
        int vHeight = mImgView.getHeight();

        mBitmap = Bitmap.createBitmap(vWidth, vHeight, Bitmap.Config.ARGB_8888);
        mImgView.setImageBitmap(mBitmap);
        mColorBackground = ResourcesCompat.getColor(getResources(), R.color.yellow, null);
        mCanvas = new Canvas(mBitmap);
        mCanvas.drawColor(mColorBackground);

//        drawHead();
        mCanvas.drawOval(vWidth/2-300, vHeight/2-200, vWidth/2+300, vHeight/2+200, mHeadPaint);
//        drawRightEye();
        mCanvas.drawOval(vWidth/2+100, vHeight/2-50, vWidth/2+200, vHeight/2+50, mCirclePaint);
//        drawLeftEye();
        mCanvas.drawOval(vWidth/2-200, vHeight/2-50, vWidth/2-100, vHeight/2+50, mCirclePaint);
//        drawEyeConnector();
        mCanvas.drawRect(vWidth/2-150, vHeight/2-10, vWidth/2+150, vHeight/2+10, mCirclePaint);
    }

}