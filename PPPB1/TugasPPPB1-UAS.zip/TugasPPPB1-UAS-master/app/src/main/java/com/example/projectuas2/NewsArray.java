package com.example.projectuas2;

import java.util.ArrayList;

public class NewsArray{
    ArrayList<News> news;
}