@extends('layouts.app')

@section('content')

@if (Auth::check() && Auth::user()->level == 'admin')
    @if (Session::has('pesanTambah'))
        <div class="alert alert-success">{{ Session::get('pesanTambah') }}</div>
    @endif
    @if (Session::has('pesanHapus'))
        <div class="alert alert-success">{{ Session::get('pesanHapus') }}</div>
    @endif
    @if (Session::has('pesanEdit'))
        <div class="alert alert-success">{{ Session::get('pesanEdit') }}</div>
    @endif

    <div class="container justify-content-center text-center mt-3">
        <p class="display-6">Tabel Pengguna</p>
        <form action="{{ route('akun.search') }}" method="get">
            @csrf
            <input type="text" name="kata" id="kata" class="form-control mb-3" placeholder="Cari..." style="width: 30%;
            display:inline; margin-top:10px; float:right;">
        </form>
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th colspan="2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data_acc as $row_user)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ $row_user->name }}</td>
                    <td>{{ $row_user->email }}</td>
                    <td>{{ $row_user->level }}</td>
                    <td>
                        <form action="{{ route('akun.destroy', $row_user->id) }}" method="post">
                            @csrf
                            <button class="btn btn-danger" onclick="return confirm('Yakin akan menghapus?')">Hapus</button>
                        </form>
                    </td>
                    <td>    
                        <form action="{{ route('akun.update', $row_user->id) }}" method="post">
                            @csrf
                            <button class="btn btn-success">Edit</button>
                        </form>
                    </td>
                </tr>
                @endforeach
                <tr>
                    <td colspan="6">
                        <a class="btn btn-primary" href="{{ route('akun.create') }}" role="button">Tambah Akun</a>
                    </td>
                </tr>
            </tbody>
        </table>
        <div>
            <strong>Jumlah Akun: {{ $jumlah_data }}</strong>
        </div>
        <div>
            {{ $data_acc->links() }}
            {{-- 'pagination::bootstrap-4' --}}
        </div>
    </div>

@else
    <p class="display-6 text-center mt-3">Maaf Anda bukan Admin</p>
@endif
@endsection