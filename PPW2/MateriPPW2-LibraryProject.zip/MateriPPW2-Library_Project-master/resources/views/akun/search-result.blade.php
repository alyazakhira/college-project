@extends('layouts.app')

@section('content')
    @if (count($data_acc))
        <div class="alert alert-success">
            Ditemukan <strong>{{ count($data_acc) }}</strong> data dengan kata: <strong>{{ $cari }}</strong>
        </div>
    @else
        <div class="row alert alert-warning">
            <div class="col-4">Data <strong>{{ $cari }}</strong> tidak ditemukan</div>
        </div>
    @endif
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script> 
    <div class="container justify-content-center text-center mt-3">
        <p class="display-6">Tabel Pengguna</p>
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th colspan="2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data_acc as $row_user)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ $row_user->name }}</td>
                    <td>{{ $row_user->email }}</td>
                    <td>{{ $row_user->level }}</td>
                    <td>
                        <form action="{{ route('akun.destroy', $row_user->id) }}" method="post">
                            @csrf
                            <button class="btn btn-danger" onclick="return confirm('Yakin akan menghapus?')">Hapus</button>
                        </form>
                    </td>
                    <td>    
                        <form action="{{ route('akun.update', $row_user->id) }}" method="post">
                            @csrf
                            <button class="btn btn-success">Edit</button>
                        </form>
                    </td>
                </tr>
                @endforeach
                <tr>
                    <td colspan="6">
                        <a class="btn btn-primary" href="{{ route('akun.create') }}" role="button">Tambah Akun</a>
                    </td>
                </tr>
            </tbody>
        </table>
        <div>
            <strong>Jumlah Akun: {{ $jumlah_data }}</strong>
        </div>
        <div>
            {{ $data_acc->links() }}
            {{-- 'pagination::bootstrap-4' --}}
        </div>
    </div>

@endsection