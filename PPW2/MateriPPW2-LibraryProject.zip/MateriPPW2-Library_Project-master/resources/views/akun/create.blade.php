@extends('layouts.app')

@section('content')
    
    <div class="container">
      @if (count($errors) > 0)
      <div class="alert alert-danger">
        <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
        </ul>
      </div>
      @endif
    <p class="display-5 text-center">Tambah Akun</p>
    <form method="post" action="{{ route('akun.store') }}">
        @csrf
        <div class="col-12 mt-3">
            <label for="name" class="form-label">Nama</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Nama">
        </div>
        <div class="col-12 mt-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Email">
        </div>
        <div class="col-12 mt-3">
            <label for="level" class="form-label">Level</label>
            <input type="text" class="form-control" id="level" name="level" placeholder="Level">
        </div>
        <div class="col-12 mt-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" placeholder="*****" id="password" name="password">
        </div>
        <div class="col-12 mt-4">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a class="btn btn-primary ms-3" href="/akun">Batal</a>
        </div>
    </form>
    </div>

@endsection