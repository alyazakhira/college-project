@extends('layouts.app')

@section('content')

@if (Auth::check() && Auth::user()->level == 'admin')
    @if (Session::has('pesanTambah'))
        <div class="alert alert-success">{{ Session::get('pesanTambah') }}</div>
    @endif
    @if (Session::has('pesanHapus'))
        <div class="alert alert-success">{{ Session::get('pesanHapus') }}</div>
    @endif
    @if (Session::has('pesanEdit'))
        <div class="alert alert-success">{{ Session::get('pesanEdit') }}</div>
    @endif
    
    <div class="container justify-content-center text-center mt-3">
        <p class="display-6">Tabel Buku</p>
        <form action="{{ route('buku.search') }}" method="get">
            @csrf
            <input type="text" name="kata" id="kata" class="form-control mb-3" placeholder="Cari..." style="width: 30%;
            display:inline; margin-top:10px; float:right;">
        </form>
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul Buku</th>
                    <th>Penulis</th>
                    <th>Harga</th>
                    <th>Tanggal Terbit</th>
                    <th colspan="4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data_buku as $row_buku)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ $row_buku->judul }}</td>
                    <td>{{ $row_buku->penulis }}</td>
                    <td>{{ "Rp ".number_format($row_buku->harga,0,',','.') }}</td>
                    <td>{{ $row_buku->tgl_terbit->format('d/m/Y') }}</td>
                    <td>
                        <form action="{{ route('buku.destroy', $row_buku->id) }}" method="post">
                            @csrf
                            <button class="btn btn-danger" onclick="return confirm('Yakin akan menghapus?')">Hapus</button>
                        </form>
                    </td>
                    <td>    
                        <a href="{{ route('buku.update', $row_buku->id) }}" class="btn btn-success">
                            Edit
                        </a>
                    </td>
                    <td>    
                        <a href="{{ route('buku.detail', $row_buku->buku_seo) }}" class="btn btn-primary">
                            Photo
                        </a>
                    </td>
                    <td>
                        <form action="{{ route('buku.like',$row_buku->id) }}" method="POST">
                            @csrf
                            <button class="btn btn-primary"> 
                                Like
                                <span class="badge badge-light">{{ $row_buku->suka }}</span>
                            </button>
                        </form>
                    </td>
                </tr>
                @endforeach
                <tr>
                    <td colspan="6">Jumlah Data</td>
                    <td colspan="3">{{ $jumlah_data }}</td>
                </tr>
                <tr>
                    <td colspan="6">Total Harga</td>
                    <td colspan="3">{{ $total_harga }}</td>
                </tr>
                <tr>
                    <td colspan="9">
                        <a class="btn btn-primary" href="{{ route('buku.create') }}" role="button">Tambah Buku</a>
                    </td>
                </tr>
            </tbody>
        </table>
        <div>
            <strong>Jumlah Buku: {{ $jumlah_data }}</strong>
        </div>
        <div>
            {{ $data_buku->links() }}
            {{-- 'pagination::bootstrap-4' --}}
        </div>
    </div>
 @else     
    <div class="container justify-content-center text-center mt-3">
        <p class="display-6">Tabel Buku</p>
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul Buku</th>
                    <th>Penulis</th>
                    <th>Harga</th>
                    <th>Tanggal Terbit</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data_buku as $row_buku)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ $row_buku->judul }}</td>
                    <td>{{ $row_buku->penulis }}</td>
                    <td>{{ "Rp ".number_format($row_buku->harga,0,',','.') }}</td>
                    <td>{{ $row_buku->tgl_terbit->format('d/m/Y') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endif
@endsection