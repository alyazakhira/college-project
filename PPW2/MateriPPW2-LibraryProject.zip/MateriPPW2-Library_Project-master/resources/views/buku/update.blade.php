@extends('layouts.app')

@section('content')
    <script type="text/javascript">
        $('.date').datepicker({
            format: 'yyyy/mm/dd',
            autoclose: 'true'
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
    <div class="container">
    <p class="display-5 text-center">Ubah Data Buku</p>
    <form method="post" action="{{ route('buku.edit', $buku->id) }}">
        @csrf
        <div class="col-12 mt-3">
            <label for="judul" class="form-label">Judul</label>
            <input type="text" class="form-control" id="judul" name="judul" placeholder="Judul" value="{{ $buku->judul }}">
        </div>
        <div class="col-12 mt-3">
            <label for="penulis" class="form-label">Penulis</label>
            <input type="text" class="form-control" id="penulis" name="penulis" placeholder="Penulis" value="{{ $buku->penulis }}">
        </div>
        <div class="col-12 mt-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="text" class="form-control" id="harga" name="harga" placeholder="000000" value="{{ $buku->harga }}">
        </div>
        <div class="col-12 mt-3">
            <label for="tgl_terbit" class="form-label">Tgl Terbit</label>
            <input type="text" class="date form-control" placeholder="yyyy/mm/dd" id="tgl_terbit" name="tgl_terbit" value="{{ $buku->tgl_terbit }}">
        </div>
        <div class="col-12 mt-4">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a class="btn btn-warning ms-3" href="/buku">Batal</a>
        </div>
    </form>
    </div>

@endsection