@extends('layouts.app')

@section('content')

@if (Auth::check() && Auth::user()->level == 'admin')
@if (Session::has('pesan'))
<div class="alert alert-success">{{ Session::get('pesan') }}</div>
@endif
    <section id='album' class="py-1 text-center bg-light">
        <div class="container justify-content-center text-center mt-3">
            <p class="display-6">{{ $buku->judul }}</p>
            <hr>
            <div class="row">
                @foreach ($galeri as $data)
                    <div class="col-md-4">
                        <a href="{{ asset('images/'.$data->foto) }}"
                            data-lightbox="image-1" data-title="{{ $data->keterangan }}">
                            <img src="{{ asset('images/'.$data->foto) }}" style="width: 200px; height:150px">
                        </a>
                        <p><h5>{{ $data->nama_galeri }}</h5></p>
                    </div>
                @endforeach
            </div>
            <div>
                {{ $galeri->links() }}
            </div>
            <div class="row">
                <form method="POST" action="{{ route('komentar.store') }}" class="mt-3">
                    @csrf
                    <textarea class="form-control" name="komentar">Tulis komentar Anda disini.</textarea>
                    <input type="number" class="visually-hidden" value="{{ Auth::user()->id }}" name="id_user">
                    <input type="number" class="visually-hidden" value="{{ $buku->id }}" name="id_buku">
                    <div class="d-grid gap-2 mt-3">
                        <button class="btn btn-primary" type="submit">Submit</button>
                    </div>
                </form>
            </div>
            <div class="row mt-5">
                <div class="text-center">Komentar</div>
                @foreach ($komentar as $komen)
                <div class="col-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">{{ $komen->user->name }}</h5>
                            <hr>
                            <p class="card-text">{{ $komen->komentar }}</p>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section> 
@endif
@endsection