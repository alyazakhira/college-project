@extends('layouts.app')

@section('content')
    @if (count($data_buku))
        <div class="alert alert-success">
            Ditemukan <strong>{{ count($data_buku) }}</strong> data dengan kata: <strong>{{ $cari }}</strong>
        </div>
    @else
        <div class="row alert alert-warning">
            <div class="col-4">Data <strong>{{ $cari }}</strong> tidak ditemukan</div>
        </div>
    @endif
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script> 
    <div class="container justify-content-center text-center mt-3">
        <p class="display-6">Tabel Buku</p>
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul-Buku</th>
                    <th>Penulis</th>
                    <th>Harga</th>
                    <th>Tgl-Terbit</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data_buku as $row_buku)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ $row_buku->judul }}</td>
                    <td>{{ $row_buku->penulis }}</td>
                    <td>{{ "Rp ".number_format($row_buku->harga,2,',','.') }}</td>
                    <td>{{ $row_buku->tgl_terbit->format('d/m/Y') }}</td>
                </tr>
                @endforeach
                <tr>
                    <td colspan="5">
                        <a class="btn btn-primary" href="/buku" role="button">Kembali</a>
                    </td>
                </tr>
            </tbody>
        </table>
        <div>
            {{ $data_buku->links() }}
            {{-- 'pagination::bootstrap-4' --}}
        </div>
    </div>
@endsection