@extends('layouts.app')

@section('content')
    <div class="container">
        @if (count($errors) > 0)
        <div class="alert alert-danger">
          <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
        @endif
    <p class="display-5 text-center">Perbarui Data Galeri</p>
    <form method="post" action="{{ route('galeri.update', $galeri->id) }}" enctype="multipart/form-data">
        @csrf
        <div class="col-12 mt-3">
            <label for="nama_galeri" class="form-label">Nama Galeri</label>
            <input type="text" class="form-control" id="nama_galeri" name="nama_galeri" value="{{ $galeri->nama_galeri }}">
        </div>
        <div class="col-12 mt-3">
            <label for="id_buku" class="form-label">Judul Buku</label>
            <select name="id_buku" id="id_buku"  class="form-control">
                <option value="{{ $galeri->id_buku }}">Pilih Buku</option>
                @foreach ($buku as $data_buku)
                    <option value="{{ $data_buku->id }}">{{ $data_buku->judul }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-12 mt-3">
            <label for="keterangan" class="form-label">Keterangan</label>
            <textarea class="form-control" id="keterangan" name="keterangan" placeholder="Tulis Keterangan" value="{{ $galeri->keterangan }}"></textarea>
        </div>
        <div class="col-12 mt-3">
            <label for="foto" class="form-label">Upload Foto</label>
            <input type="file" class="form-control" id="foto" name="foto">
        </div>
        <div class="col-12 mt-4">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a class="btn btn-primary" href="/galeri">Batal</a>
        </div>
    </form>
    </div>

@endsection