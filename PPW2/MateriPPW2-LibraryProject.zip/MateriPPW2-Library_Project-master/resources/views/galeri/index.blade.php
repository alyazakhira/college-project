@extends('layouts.app')

@section('content')

@if (Auth::check() && Auth::user()->level == 'admin')
    @if (Session::has('pesanTambah'))
        <div class="alert alert-success">{{ Session::get('pesanTambah') }}</div>
    @endif
    @if (Session::has('pesanHapus'))
        <div class="alert alert-success">{{ Session::get('pesanHapus') }}</div>
    @endif
    @if (Session::has('pesanEdit'))
        <div class="alert alert-success">{{ Session::get('pesanEdit') }}</div>
    @endif
    
    <div class="container justify-content-center text-center mt-3">
        <p class="display-6">Galeri Buku</p>
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Galeri</th>
                    <th>Judul Buku</th>
                    <th>Gambar</th>
                    <th colspan="2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($galeri as $row_galeri)

                <tr>
                    <td>{{ ++$no }}</td>
                    <td>{{ $row_galeri->nama_galeri }}</td>
                    <td>{{ $row_galeri->bukus->judul }}</td>
                    <td><img src="{{ asset('thumb/'.$row_galeri->foto) }}" style="max-width: 100px"></td>
                    <td>
                        <form action="{{ route('galeri.destroy', $row_galeri->id) }}" method="post">
                            @csrf
                            <button class="btn btn-danger" onclick="return confirm('Yakin akan menghapus?')">Hapus</button>
                        </form>
                    </td>
                    <td>    
                        <a href="{{ route('galeri.edit', $row_galeri->id) }}" class="btn btn-info">Edit</a>
                    </td>
                </tr>

                @endforeach
                <tr>
                    <td colspan="6">
                        <a class="btn btn-primary" href="{{ route('galeri.create') }}" role="button">Tambah Galeri</a>
                    </td>
                </tr>
            </tbody>
        </table>
        <div>
            {{ $galeri->links() }}
            {{-- 'pagination::bootstrap-4' --}}
        </div>
    </div>
@else
    <p class="display-6 text-center mt-3">Maaf Anda bukan Admin</p>
@endif
@endsection