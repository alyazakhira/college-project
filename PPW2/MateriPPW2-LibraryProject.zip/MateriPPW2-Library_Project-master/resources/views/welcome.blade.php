@extends('layouts.app')

@section('content')

<div class="container justify-content-center text-center mt-3">
    <p class="display-6">Tabel Buku</p>
    <table class="table table-stripped">
        <thead>
            <tr>
                <th>No</th>
                <th>Judul Buku</th>
                <th>Penulis</th>
                <th>Harga</th>
                <th>Tanggal Terbit</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data_buku as $row_buku)
            <tr>
                <td>{{ $no++ }}</td>
                <td>{{ $row_buku->judul }}</td>
                <td>{{ $row_buku->penulis }}</td>
                <td>{{ "Rp ".number_format($row_buku->harga,0,',','.') }}</td>
                <td>{{ $row_buku->tgl_terbit->format('d/m/Y') }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection