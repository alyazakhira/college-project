<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BukuController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(){
        $data_buku = Buku::all();
        $batas = 5;
        $data_buku = Buku::orderBy('id','desc')->paginate($batas);
        $jumlah_data = Buku::count();
        $total_harga = Buku::sum('harga');
        $no = $batas * ($data_buku->currentPage() - 1);
        return view('buku.index', compact('data_buku','jumlah_data','total_harga','no'));
    }

    public function create(){
        return view('buku.create');
    }

    public function store(Request $request){
        $this->validate($request,[
            'judul' => 'required|string',
            'penulis' => 'required|string|max:30',
            'harga' => 'required|numeric',
            'tanggal_terbit' => 'required|date'
        ]);
        $buku = new Buku;
        $buku->judul = $request->judul;
        $buku->buku_seo = Str::slug($request->judul, '-');
        $buku->penulis = $request->penulis;
        $buku->harga = $request->harga;
        $buku->tgl_terbit = $request->tanggal_terbit;
        $buku->save();
        return redirect('/buku')->with('pesanTambah','Data Buku berhasil disimpan');
    }

    public function destroy($id) {
        $buku = Buku::find($id);
        $buku->delete();
        return redirect('/buku')->with('pesanHapus','Data Buku berhasil dihapus');
    }

    public function update($id){
        $buku = Buku::find($id);
        return view('buku.update',compact('buku'));
    }

    public function edit(Request $request,$id){
        $buku = Buku::find($id);
        $buku->judul = $request->judul;
        $buku->buku_seo = Str::slug($request->judul, '-');
        $buku->penulis = $request->penulis;
        $buku->harga = $request->harga;
        $buku->tgl_terbit = $request->tgl_terbit;
        $buku->save();
        return redirect('/buku')->with('pesanEdit','Data Buku berhasil diubah');
    }

    public function search(Request $request){
        $batas = 5;
        $cari = $request->kata;
        $data_buku = Buku::where('judul','like',"%" . $cari . "%")->orwhere('penulis','like',"%".$cari."%")->paginate($batas);
        $no = $batas * ($data_buku->currentPage() - 1);
        return view('buku.search-result', compact('data_buku','no','cari'));
    }

    public function show($seo){
        $buku = Buku::where('buku_seo',$seo)->first();
        $komentar = $buku->komentar()->orderBy('id','asc')->get();
        $galeri = $buku->galeri()->orderBy('id','desc')->paginate(6);
        return view('buku.detail',compact('buku','galeri','komentar'));
    }

    public function like($id){
        $buku = Buku::find($id);
        $buku->increment('suka');
        return back();
    }
}

