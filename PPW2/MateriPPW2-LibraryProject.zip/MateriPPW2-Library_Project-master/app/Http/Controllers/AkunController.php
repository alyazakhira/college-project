<?php

namespace App\Http\Controllers;

use App\Models\Akun;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AkunController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(){
        $data_acc = Akun::all();
        $batas = 5;
        $jumlah_data = Akun::count();
        $data_acc = Akun::orderBy('id')->paginate($batas);
        $no = $batas * ($data_acc->currentPage() - 1);
        return view('akun.index', compact('data_acc','no','jumlah_data'));
    }

    public function create(){
        return view('akun.create');
    }

    public function store(Request $request){
        $this->validate($request,[
            'name' => 'required|string',
            'email' => 'required|email',
            'password' => 'required|string',
            'level' => 'required|string'
        ]);
        $akun = new Akun;
        $akun->name = $request->name;
        $akun->email = $request->email;
        $akun->password = Hash::make($request->password);
        $akun->level = $request->level;
        $akun->save();
        return redirect('/akun')->with('pesanTambah','Data Akun berhasil disimpan');
    }

    public function destroy($id) {
        $akun = Akun::find($id);
        $akun->delete();
        return redirect('/akun')->with('pesanHapus','Data Akun berhasil dihapus');
    }

    public function update($id){
        $akun = Akun::find($id);
        return view('akun.update',compact('akun'));
    }

    public function edit(Request $request,$id){
        $akun = Akun::find($id);
        $akun->name = $request->name;
        $akun->email = $request->email;
        $akun->password = Hash::make($request->password);
        $akun->level = $request->level;
        $akun->save();
        return redirect('/akun')->with('pesanEdit','Data Akun berhasil diubah');
    }

    public function search(Request $request){
        $batas = 5;
        $cari = $request->kata;
        $data_acc = Akun::where('nama','like',"%" . $cari . "%")->orwhere('email','like',"%".$cari."%")->paginate($batas);
        $no = $batas * ($data_acc->currentPage() - 1);
        return view('akun.search-result', compact('data_acc','no','cari'));
    }
}
