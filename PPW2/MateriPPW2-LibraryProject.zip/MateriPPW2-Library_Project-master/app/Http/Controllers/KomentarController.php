<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Komentar;

class KomentarController extends Controller
{
    public function store(Request $request){
        $this->validate($request,[
            'komentar' => 'required|string',
        ]);

        $komentar = new Komentar;
        $komentar->komentar = $request->komentar;
        $komentar->id_user = $request->id_user;
        $komentar->id_buku = $request->id_buku;
        $komentar->save();
        return back()->with('pesan','Komentar Anda berhasil diunggah');
    }
}
