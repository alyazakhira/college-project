<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Buku;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        User::create([
            'name' => 'Alya Zakhira',
            'email' => 'zakhiralya@gmail.com',
            'password' => Hash::make('12345'),
            'level' => 'admin',
        ]);

        User::create([
            'name' => 'Aleza Redova',
            'email' => 'alezaredova@gmail.com',
            'password' => Hash::make('12345'),
            'level' => 'user',
        ]);

        Buku::create([
            'judul' => 'Crysa; Reunion',
            'buku_seo' => 'crysa-reunion',
            'penulis' => 'Yotsuha Eiyri',
            'harga' => 97000,
            'tgl_terbit' => '2022-11-01',
            'suka' => 0,
        ]);

        Buku::create([
            'judul' => 'Crysa; Unfalthering',
            'buku_seo' => 'crysa-unfal',
            'penulis' => 'Yotsuha Eiyri',
            'harga' => 95000,
            'tgl_terbit' => '2022-11-02',
            'suka' => 0,
        ]);

        Buku::create([
            'judul' => 'Crysa; Illien',
            'buku_seo' => 'crysa-illien',
            'penulis' => 'Yotsuha Eiyri',
            'harga' => 98000,
            'tgl_terbit' => '2022-11-03',
            'suka' => 0,
        ]);

    }
}
