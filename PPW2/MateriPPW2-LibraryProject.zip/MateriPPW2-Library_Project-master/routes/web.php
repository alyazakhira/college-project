<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BukuController;
use App\Http\Controllers\AkunController;
use App\Http\Controllers\GaleriController;
use App\Http\Controllers\KomentarController;
use App\Models\Buku;


Route::get('/', function () {
    $data_buku = Buku::all();
    $batas = 5;
    $data_buku = Buku::orderBy('id')->paginate($batas);
    $no = $batas * ($data_buku->currentPage() - 1);
    return view('welcome', compact('data_buku','no'));
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Buku
Route::get('/buku',[BukuController::class, 'index'])->name('buku.index');
Route::get('/buku/create',[BukuController::class, 'create'])->name('buku.create');
Route::post('/buku/store',[BukuController::class, 'store'])->name('buku.store');
Route::post('/buku/delete/{id}',[BukuController::class, 'destroy'])->name('buku.destroy');
Route::get('/buku/update/{id}',[BukuController::class, 'update'])->name('buku.update');
Route::post('/buku/edit/{id}',[BukuController::class, 'edit'])->name('buku.edit');
Route::get('/buku/search',[BukuController::class, 'search'])->name('buku.search');
Route::get('/buku/detail/{seo}', [BukuController::class,'show'])->name('buku.detail');
Route::post('/buku/suka/{id}',[BukuController::class, 'like'])->name('buku.like');

// Komentar
Route::post('/komentar/store',[KomentarController::class, 'store'])->name('komentar.store');

// Akun
Route::get('/akun',[AkunController::class, 'index'])->name('akun.index');
Route::get('/akun/create',[AkunController::class, 'create'])->name('akun.create');
Route::post('/akun/store',[AkunController::class, 'store'])->name('akun.store');
Route::post('/akun/delete/{id}',[AkunController::class, 'destroy'])->name('akun.destroy');
Route::post('/akun/update/{id}',[AkunController::class, 'update'])->name('akun.update');
Route::post('/akun/edit/{id}',[AkunController::class, 'edit'])->name('akun.edit');
Route::get('/akun/search',[AkunController::class, 'search'])->name('akun.search');

// Galeri
Route::get('/galeri', [GaleriController::class,'index'])->name('galeri.index');
Route::get('/galeri/create', [GaleriController::class,'create'])->name('galeri.create');
Route::post('/galeri', [GaleriController::class,'store'])->name('galeri.store');
Route::get('/galeri/edit/{id}',[GaleriController::class,'edit'])->name('galeri.edit');
Route::post('/galeri/update/{id}',[GaleriController::class,'update'])->name('galeri.update');
Route::post('/galeri/delete/{id}',[GaleriController::class,'destroy'])->name('galeri.destroy');