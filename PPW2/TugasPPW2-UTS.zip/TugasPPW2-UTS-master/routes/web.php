<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UTSController;

Route::get('/', [UTSController::class, 'showHome']);
Route::get('/initial', [UTSController::class, 'showInitialization']);
Route::get('/idol', [UTSController::class, 'showIdola']);
