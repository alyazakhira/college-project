@extends('layout.layout-master')

@section('isi-konten')

    {{-- Judul Tabel --}}
    <div class="container justify-content-center text-center mt-5">
        <p class="display-5">Tabel Idola</p>
    </div>

    {{-- Tabel --}}
    <div class="container justify-content-center text-center mt-5">
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>No ID</th>
                    <th>Nama-Idola</th>
                    <th colspan="3">Alasan</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data_idola as $row_idola)
                <tr>
                    <td>{{ $row_idola->id }}</td>
                    <td>{{ $row_idola->nama }}</td>
                    <td colspan="3">{{ $row_idola->alasan }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    
@endsection