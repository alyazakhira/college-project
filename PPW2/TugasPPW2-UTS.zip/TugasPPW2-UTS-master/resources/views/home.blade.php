@extends('layout.layout-master')

@section('isi-konten')
    <div class="container vh-100 text-center m-auto">
        <div class="row align-items-center align-self-center h-75">
            <p class="display-5">UTS WEB 2 - Alya Zakhira</p> 
        </div>       
    </div>
    
@endsection