@extends('layout.layout-master')

@section('isi-konten')

{{-- Judul --}}
    <div class="container text-center mt-5">
        <p class="display-5">Penjelasan Soal No 1</p>
    </div>

{{-- Pembuatan Proyek --}}
<div class="container mt-5">
    <div class="container">
        <h2>A. Pembuatan Proyek</h2>
    </div>
    <div class="container">
        <p>Proyek dibuat melalui CMD dengan memasukkan perintah seperti gambar di bawah</p>
        <img src="image/create-project_command.png">
    </div>
</div>

{{-- Menyambungkan dengan DB --}}
<div class="container mt-5">
    <div class="container">
        <h2>B. Menyambungkan dengan DB</h2>
    </div>
    <div class="container">
        <p>Kemudian menyambungkan proyek dengan database "idolaqu" melalui file .env, caranya cukup mengganti
            isian file .env pada bagian database seperti gambar di bawah.
        </p>
        <img src="image/connect-db_env.png" style="width:25%">
    </div>
</div>    

@endsection