<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Idola;

class UTSController extends Controller
{
    public function showHome(){
        return view('home');
    }

    public function showInitialization(){
        return view('initial');
    }

    public function showIdola(){
        $data_idola = Idola::all();
        return view('idola',compact('data_idola'));
    }
}
